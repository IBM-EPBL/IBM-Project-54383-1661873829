# CLOUD OBJECT STORAGE

# CREATE A IBM OBJECT STORAGE
![image](https://user-images.githubusercontent.com/89722457/193893030-9ab99a86-3bfa-4a7f-bacb-f0632ef87dcc.png)

# CREATE A BUCKET TO STORE FILES
![image](https://user-images.githubusercontent.com/89722457/193893154-5753c9f5-d2b8-41e5-9ebd-a13b6706a631.png)

# CREATE SERVICE CREDENTIALS
![image](https://user-images.githubusercontent.com/89722457/193893282-7519bdd7-1b54-4dbf-8d9b-5b415ea0f7ed.png)

# UPLOAD FILES IN THE BUCKET
![image](https://user-images.githubusercontent.com/89722457/193893463-9873bf93-fd6d-45e6-9080-127ff8992f78.png)

# INTEGRATE THE CLOUD OBJECT STORAGE WITH FLASK AND RUN IT IN YOUR LOCAL MACHINE
![image](https://user-images.githubusercontent.com/89722457/193893716-94d22d8d-5838-4144-9437-7f80b960987f.png)

> TO RUN
```
clone the repo
open cmd
navigate to the folder
run the command - flask --debug run

```
