# CHATBOT USING IBM WATSON ASSISTANT

# CREATE A WATSON SERVICE
![image](https://user-images.githubusercontent.com/89722457/193894292-3fc1cdf4-17ce-48d7-a74e-8d00ca4a3542.png)

# LAUNCH THE SERVICE AND CREATE A NEW CHATBOT
![image](https://user-images.githubusercontent.com/89722457/193894471-bb8ceb4e-11cf-4405-9667-a6ae498d93a4.png)

# CUSTOMIZE THE CHATBOT ACTION AND PUBLISH IN WEBCHAT LIVE ENVIRONMENT
![image](https://user-images.githubusercontent.com/89722457/193894873-e2b9400e-d757-4f9d-a3f9-dbfadcafe565.png)

![image](https://user-images.githubusercontent.com/89722457/193895050-f299e038-55b4-4927-8ca4-5d51d460b43f.png)

# EMBED THE SCRIPT IN YOUR APPLICATION AND RUN
![image](https://user-images.githubusercontent.com/89722457/193895331-8d2604a8-7ab8-4af0-83eb-ac62e3cc3072.png)

> TO RUN
```
clone the repo
navigate to the folder
run the command in cmd - flask --debug run
```
